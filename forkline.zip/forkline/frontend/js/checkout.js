/* ==========================================================
   checkout.js — Checkout + Order confirmation
   1. Shows the cart (GET /api/cart) and a delivery form.
   2. Validates the form, then sends ONLY name, phone and address:
        POST /api/orders { customerName, phone, address }
      (The backend takes the items and prices from MongoDB — the browser
       never sends a price or a total.)
   3. Shows the order confirmation. After a successful order the address becomes
      checkout.html?order=FLK-XXXXXX, which loads the order again with
        GET /api/orders/:orderRef
   ========================================================== */

(function () {
  const content = document.getElementById('checkoutContent');
  const title = document.getElementById('checkoutTitle');
  const subtitle = document.getElementById('checkoutSubtitle');
  const orderRefFromUrl = new URLSearchParams(window.location.search).get('order');

  // ----- Validation (the backend checks the same rules again) -----

  function cleanPhone(value) {
    return value.replace(/[\s\-()]/g, '').replace(/^(\+91|91|0)(?=\d{10}$)/, '');
  }

  function validate(values) {
    const errors = {};
    if (values.customerName.length < 2 || values.customerName.length > 60) errors.customerName = 'Please enter your name (2 to 60 characters).';
    if (!/^[6-9]\d{9}$/.test(cleanPhone(values.phone))) errors.phone = 'Enter a valid 10-digit mobile number.';
    if (values.address.length < 10 || values.address.length > 250) errors.address = 'Please enter your full address (at least 10 characters).';
    return errors;
  }

  function showFieldErrors(form, errors) {
    ['customerName', 'phone', 'address'].forEach((field) => {
      const input = form.elements[field];
      const message = form.querySelector(`[data-error-for="${field}"]`);
      input.classList.toggle('is-invalid', Boolean(errors[field]));
      message.textContent = errors[field] || '';
    });
  }

  function showFormAlert(message) {
    const box = document.getElementById('formAlert');
    box.innerHTML = message
      ? `<div class="alert alert-danger d-flex gap-2 align-items-start" role="alert"><i class="bi bi-exclamation-triangle-fill"></i><div>${esc(message)}</div></div>`
      : '';
  }

  // ----- Checkout form -----

  function renderCheckout(cart) {
    subtitle.textContent = 'Tell us where to deliver your food.';
    content.innerHTML = `
      <div class="row g-4">
        <div class="col-lg-7">
          <form id="checkoutForm" class="form-card" novalidate>
            <h2 class="fs-4 fw-bold mb-3">Delivery details</h2>
            <div id="formAlert"></div>
            <div class="mb-3">
              <label for="customerName">Full name</label>
              <input id="customerName" name="customerName" class="form-control" placeholder="e.g. Niharika Sharma" maxlength="60" autocomplete="name">
              <div class="invalid-feedback" data-error-for="customerName"></div>
            </div>
            <div class="mb-3">
              <label for="phone">Contact number</label>
              <input id="phone" name="phone" class="form-control" placeholder="10-digit mobile number" inputmode="numeric" maxlength="16" autocomplete="tel">
              <div class="invalid-feedback" data-error-for="phone"></div>
            </div>
            <div class="mb-4">
              <label for="address">Delivery address</label>
              <textarea id="address" name="address" class="form-control" rows="3" placeholder="House no., street, area, city" maxlength="250" autocomplete="street-address"></textarea>
              <div class="invalid-feedback" data-error-for="address"></div>
            </div>
            <button id="placeOrderBtn" type="submit" class="btn fk-btn w-100 py-2"><i class="bi bi-bag-check"></i> Place Order · ${formatPrice(cart.totalAmount)}</button>
            <p class="text-muted small text-center mt-2 mb-0">No payment needed for this demo. Pay on delivery.</p>
          </form>
        </div>
        <div class="col-lg-5">
          <aside class="summary-card">
            <h3>Review your order</h3>
            ${cart.items
              .map((i) => `<div class="mini-line"><span>${i.quantity} × ${esc(i.name)}</span><strong>${formatPrice(i.subtotal)}</strong></div>`)
              .join('')}
            <div class="summary-row total"><span>Total</span><span>${formatPrice(cart.totalAmount)}</span></div>
            <a href="cart.html" class="btn fk-btn-outline w-100 mt-3">Edit cart</a>
          </aside>
        </div>
      </div>`;

    const form = document.getElementById('checkoutForm');
    form.addEventListener('submit', (event) => submitOrder(event, form));
  }

  async function submitOrder(event, form) {
    event.preventDefault();
    showFormAlert('');

    const values = {
      customerName: form.elements.customerName.value.trim(),
      phone: form.elements.phone.value.trim(),
      address: form.elements.address.value.trim(),
    };
    const errors = validate(values);
    showFieldErrors(form, errors);
    if (Object.keys(errors).length > 0) {
      showToast('Please correct the highlighted fields.', 'warning');
      return;
    }

    // Disable the button so a double click cannot create two orders
    const button = document.getElementById('placeOrderBtn');
    const originalLabel = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Placing order…';

    try {
      const res = await Api.placeOrder(values);
      setCartBadge(0); // the backend has cleared the cart
      history.replaceState(null, '', `checkout.html?order=${encodeURIComponent(res.data.orderRef)}`);
      renderConfirmation(res.data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast('Order placed successfully!', 'success');
    } catch (err) {
      button.disabled = false;
      button.innerHTML = originalLabel;

      // Field errors reported by the backend (HTTP 400)
      if (err.errors && err.errors.length) {
        const fieldErrors = {};
        err.errors.forEach((e) => { fieldErrors[e.field] = e.message; });
        showFieldErrors(form, fieldErrors);
      }
      showFormAlert(err.message);
      showToast(err.message, 'danger');
    }
  }

  // ----- Order confirmation -----

  function renderConfirmation(order) {
    title.textContent = 'Order confirmed';
    subtitle.textContent = 'Thank you for ordering with Forkline.';
    const placedAt = new Date(order.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

    content.innerHTML = `
      <div class="success-wrap">
        <div class="success-head">
          <div class="success-check"><i class="bi bi-check-lg"></i></div>
          <h2 class="fw-bold">Your order is placed!</h2>
          <p class="text-muted mb-1">Your food is being prepared. Keep this reference handy:</p>
          <span class="order-ref">${esc(order.orderRef)}</span>
        </div>

        <div class="form-card mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fs-5 fw-bold m-0">Order summary</h3>
            <span class="status-pill">${esc(order.orderStatus)}</span>
          </div>
          ${order.items
            .map((i) => `<div class="mini-line"><span>${i.quantity} × ${esc(i.name)} <span class="text-muted">(${formatPrice(i.price)} each)</span></span><strong>${formatPrice(i.subtotal)}</strong></div>`)
            .join('')}
          <div class="summary-row total"><span>Total to pay</span><span>${formatPrice(order.totalAmount)}</span></div>
        </div>

        <div class="form-card mb-4">
          <h3 class="fs-5 fw-bold mb-3">Delivery details</h3>
          <p class="mb-1"><i class="bi bi-person text-primary me-2"></i>${esc(order.customerName)}</p>
          <p class="mb-1"><i class="bi bi-telephone text-primary me-2"></i>${esc(order.phone)}</p>
          <p class="mb-1"><i class="bi bi-geo-alt text-primary me-2"></i>${esc(order.address)}</p>
          <p class="mb-0 text-muted small mt-2"><i class="bi bi-clock me-2"></i>Placed on ${esc(placedAt)}</p>
        </div>

        <div class="d-flex flex-wrap gap-2 justify-content-center">
          <a href="restaurants.html" class="btn fk-btn"><i class="bi bi-shop"></i> Order more</a>
          <a href="index.html" class="btn fk-btn-outline"><i class="bi bi-house-door"></i> Back to home</a>
        </div>
      </div>`;
  }

  // ----- Page start -----

  async function start() {
    content.innerHTML = `<div class="row g-4"><div class="col-lg-7">${skeletonCards(1, 'col-12')}</div></div>`;
    try {
      // Opened with ?order=REF  ->  show that order
      if (orderRefFromUrl) {
        const res = await Api.getOrder(orderRefFromUrl);
        renderConfirmation(res.data);
        return;
      }

      // Normal checkout
      const res = await Api.getCart();
      setCartBadge(res.data.totalItems);
      if (res.data.items.length === 0) {
        content.innerHTML = emptyState({
          icon: '🛒',
          title: 'Your cart is empty',
          text: 'Add some food to your cart before checking out.',
          actionHtml: '<a href="restaurants.html" class="btn fk-btn">Browse restaurants</a>',
        });
      } else if (res.data.items.some((i) => !i.isAvailable)) {
        content.innerHTML = emptyState({
          icon: '😕',
          title: 'Some items are unavailable',
          text: 'Please remove the unavailable items from your cart, then come back to checkout.',
          actionHtml: '<a href="cart.html" class="btn fk-btn">Go to cart</a>',
        });
      } else {
        renderCheckout(res.data);
      }
    } catch (err) {
      const notFound = err.status === 404;
      content.innerHTML = notFound
        ? emptyState({
            icon: '🧭',
            title: 'Order not found',
            text: 'We could not find an order with that reference.',
            actionHtml: '<a href="index.html" class="btn fk-btn">Back to home</a>',
          })
        : errorState(err.message, 'Could not load checkout');
      showToast(err.message, 'danger');
    }
  }

  window.fkRetry = start;
  start();
})();
