/* ==========================================================
   main.js — shared by EVERY page
   1. small helpers (escape text, format ₹, debounce)
   2. navbar + footer + toast area (inserted by JavaScript so we write them once)
   3. reusable card / state templates
   4. "Add to cart" button handling
   5. Home page logic
   ========================================================== */

// ---------- 1. Helpers ----------

// The six categories (label shown on screen -> value stored in MongoDB)
const CATEGORIES = [
  { label: 'Pizza', value: 'Pizza', icon: '🍕' },
  { label: 'Burgers', value: 'Burger', icon: '🍔' },
  { label: 'Indian', value: 'Indian', icon: '🍛' },
  { label: 'Chinese', value: 'Chinese', icon: '🥡' },
  { label: 'Desserts', value: 'Dessert', icon: '🍰' },
  { label: 'Beverages', value: 'Beverage', icon: '🥤' },
];
const ALL_CHIP = { label: 'All', value: '', icon: '✨' };

// Shown when an image URL fails to load (a built-in picture, so it never fails itself)
const FALLBACK_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFC857"/>' +
      '<stop offset="1" stop-color="#FF6B35"/></linearGradient></defs>' +
      '<rect width="600" height="400" fill="url(#g)"/>' +
      '<text x="300" y="240" font-size="130" text-anchor="middle">🍽️</text></svg>'
  );

// Any <img> that fails to load gets the fallback picture (the "error" event does not
// bubble, so we listen in the capture phase).
document.addEventListener(
  'error',
  (event) => {
    const img = event.target;
    if (img && img.tagName === 'IMG' && !img.dataset.fallbackUsed) {
      img.dataset.fallbackUsed = '1';
      img.src = FALLBACK_IMG;
    }
  },
  true
);

// Escape text before putting it into HTML (prevents HTML injection from database text)
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// 1499 -> "₹1,499"
function formatPrice(amount) {
  return '₹' + Number(amount || 0).toLocaleString('en-IN');
}

// Waits until the user stops typing for `delay` ms before running fn (fewer API calls)
function debounce(fn, delay = 400) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function categoryMeta(value) {
  return CATEGORIES.find((c) => c.value.toLowerCase() === String(value).toLowerCase()) || { label: value, value, icon: '🍽️' };
}

// ---------- 2. Layout: navbar, footer, toasts ----------

function renderLayout() {
  const page = document.body.dataset.page;
  const links = [
    ['home', 'index.html', 'Home'],
    ['restaurants', 'restaurants.html', 'Restaurants'],
    ['menu', 'menu.html', 'Menu'],
    ['cart', 'cart.html', 'Cart'],
  ];
  const cartButton = (extra = '') =>
    `<a href="cart.html" class="fk-btn-outline cart-link text-decoration-none ${extra}" aria-label="Open cart">
       <i class="bi bi-cart3"></i><span class="d-none d-sm-inline">Cart</span>
       <span class="cart-count is-empty">0</span></a>`;

  const nav = document.getElementById('site-nav');
  if (nav) {
    nav.innerHTML = `
      <nav class="navbar navbar-expand-lg fk-navbar sticky-top">
        <div class="container">
          <a class="fk-brand" href="index.html"><span class="fk-logo">🍴</span><span>Fork<span class="accent">line</span></span></a>
          <div class="d-flex align-items-center gap-2 ms-auto order-lg-3">
            ${cartButton()}
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse"
              data-bs-target="#fkNav" aria-controls="fkNav" aria-expanded="false" aria-label="Toggle navigation">
              <i class="bi bi-list fs-2"></i></button>
          </div>
          <div class="collapse navbar-collapse order-lg-2" id="fkNav">
            <ul class="navbar-nav mx-lg-auto gap-lg-1 mt-3 mt-lg-0">
              ${links
                .map(([key, href, label]) => `<li class="nav-item"><a class="nav-link ${page === key ? 'active' : ''}" href="${href}">${label}</a></li>`)
                .join('')}
            </ul>
          </div>
        </div>
      </nav>`;
  }

  const footer = document.getElementById('site-footer');
  if (footer) {
    footer.innerHTML = `
      <footer class="fk-footer">
        <div class="container">
          <div class="row g-4">
            <div class="col-lg-5">
              <a class="fk-brand text-decoration-none" href="index.html"><span class="fk-logo">🍴</span><span>Fork<span class="accent">line</span></span></a>
              <p class="mt-3 mb-3" style="max-width:24rem">Hot food, happy moods. Order from your favourite restaurants and get it delivered fast.</p>
              <div class="fk-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" aria-label="Twitter"><i class="bi bi-twitter-x"></i></a></div>
            </div>
            <div class="col-6 col-lg-3"><h4>Explore</h4>
              <ul><li><a href="index.html">Home</a></li><li><a href="restaurants.html">Restaurants</a></li>
              <li><a href="menu.html">Menu</a></li><li><a href="cart.html">Cart</a></li></ul></div>
            <div class="col-6 col-lg-4"><h4>Popular cuisines</h4>
              <ul>${CATEGORIES.slice(0, 4).map((c) => `<li><a href="restaurants.html?cuisine=${encodeURIComponent(c.value)}">${c.icon} ${c.label}</a></li>`).join('')}</ul></div>
          </div>
          <div class="copy d-flex flex-wrap justify-content-between gap-2">
            <span>© ${new Date().getFullYear()} Forkline. MCA academic project.</span>
            <span>Built with Node.js, Express &amp; MongoDB</span>
          </div>
        </div>
      </footer>`;
  }

  if (!document.getElementById('toastArea')) {
    const area = document.createElement('div');
    area.id = 'toastArea';
    area.className = 'toast-container position-fixed top-0 end-0 p-3';
    area.style.zIndex = 1100;
    document.body.appendChild(area);
  }
}

// Bootstrap toast message. type: success | danger | warning | info
function showToast(message, type = 'success') {
  const icons = { success: 'bi-check-circle-fill', danger: 'bi-exclamation-triangle-fill', warning: 'bi-exclamation-circle-fill', info: 'bi-info-circle-fill' };
  const toastEl = document.createElement('div');
  toastEl.className = `toast fk-toast fk-toast-${type} align-items-center border-0`;
  toastEl.setAttribute('role', 'alert');
  toastEl.setAttribute('aria-live', 'assertive');
  toastEl.setAttribute('aria-atomic', 'true');
  toastEl.innerHTML = `<div class="d-flex"><div class="toast-body"><i class="bi ${icons[type] || icons.info} me-2"></i>${esc(message)}</div>
    <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
  document.getElementById('toastArea').appendChild(toastEl);

  const toast = new bootstrap.Toast(toastEl, { delay: type === 'danger' ? 5000 : 2800 });
  toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
  toast.show();
}

// Updates every cart badge in the navbar (with a small "bump" animation)
function setCartBadge(count) {
  document.querySelectorAll('.cart-count').forEach((badge) => {
    const changed = badge.textContent !== String(count);
    badge.textContent = count;
    badge.classList.toggle('is-empty', count === 0);
    if (changed && count > 0) {
      badge.classList.remove('bump');
      void badge.offsetWidth; // restart the animation
      badge.classList.add('bump');
    }
  });
}

// Reads the cart from the backend so the badge is correct on every page
async function refreshCartCount() {
  try {
    const res = await Api.getCart();
    setCartBadge(res.data.totalItems);
  } catch (err) {
    // The page itself shows a proper error message, so here we only log it.
    console.warn('Could not load cart count:', err.message);
  }
}

// ---------- 3. Reusable templates ----------

function restaurantCard(r, i = 0) {
  return `
    <div class="col-12 col-md-6 col-lg-4">
      <article class="fk-card restaurant-card fade-up" style="--i:${i}">
        <div class="fk-card-img">
          <img src="${esc(r.image)}" alt="${esc(r.name)}" loading="lazy">
          <span class="rating-pill"><i class="bi bi-star-fill"></i> ${Number(r.rating).toFixed(1)}</span>
        </div>
        <div class="fk-card-body">
          <h3>${esc(r.name)}</h3>
          <p class="cuisine">${esc(r.cuisine)}</p>
          <div class="meta">
            <span><i class="bi bi-clock"></i>${esc(r.deliveryTime)}</span>
            <span><i class="bi bi-geo-alt"></i>${esc(r.location)}</span>
          </div>
          <a class="btn fk-btn mt-auto align-self-start" href="menu.html?id=${esc(r._id)}">View Menu <i class="bi bi-arrow-right"></i></a>
        </div>
      </article>
    </div>`;
}

function foodCard(food, i = 0) {
  // When the backend "populates" restaurantId, it is an object with the restaurant name
  const restaurantName = food.restaurantId && typeof food.restaurantId === 'object' ? food.restaurantId.name : '';
  const unavailable = food.isAvailable === false;
  return `
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
      <article class="fk-card food-card fade-up ${unavailable ? 'is-unavailable' : ''}" style="--i:${i}">
        <div class="fk-card-img">
          <img src="${esc(food.image)}" alt="${esc(food.name)}" loading="lazy">
          <span class="cat-pill">${esc(food.category)}</span>
          ${unavailable ? '<span class="sold-out">UNAVAILABLE</span>' : ''}
        </div>
        <div class="fk-card-body">
          ${restaurantName ? `<p class="food-rest"><i class="bi bi-shop"></i> ${esc(restaurantName)}</p>` : ''}
          <h3>${esc(food.name)}</h3>
          <p class="desc">${esc(food.description)}</p>
          <div class="d-flex justify-content-between align-items-center mt-auto">
            <span class="price">${formatPrice(food.price)}</span>
            <button type="button" class="btn fk-btn fk-btn-sm" data-add="${esc(food._id)}" ${unavailable ? 'disabled' : ''}>
              <i class="bi bi-plus-lg"></i> Add</button>
          </div>
        </div>
      </article>
    </div>`;
}

// Grey animated placeholders shown while data is loading
function skeletonCards(count = 6, columns = 'col-12 col-md-6 col-lg-4') {
  const card = `<div class="${columns}"><div class="skeleton-card"><div class="sk sk-img"></div>
    <div class="sk sk-line"></div><div class="sk sk-line short"></div><div class="sk sk-btn"></div></div></div>`;
  return card.repeat(count);
}
const FOOD_SKELETON_COLS = 'col-12 col-sm-6 col-lg-4 col-xl-3';

function emptyState({ icon = '🍽️', title, text = '', actionHtml = '' }) {
  return `<div class="fk-state"><span class="state-icon">${icon}</span><h3>${esc(title)}</h3><p>${esc(text)}</p>${actionHtml}</div>`;
}

// Error box with a "Try again" button (the page sets window.fkRetry to its own reload function)
function errorState(message, title = 'Something went wrong') {
  return emptyState({
    icon: '⚠️',
    title,
    text: message,
    actionHtml: '<button type="button" class="btn fk-btn" data-retry><i class="bi bi-arrow-clockwise"></i> Try again</button>',
  });
}

// Wraps a state box so it spans the full width of a Bootstrap .row grid
const inGrid = (html) => `<div class="col-12">${html}</div>`;

function categoryChipsHtml(list, activeValue) {
  return list
    .map((c) => `<button type="button" class="fk-chip ${c.value === activeValue ? 'active' : ''}" data-value="${esc(c.value)}"><span>${c.icon}</span>${esc(c.label)}</button>`)
    .join('');
}

// ---------- 4. Global click handlers: Add to cart + Try again ----------

async function handleAddToCart(button) {
  if (button.disabled) return;
  const original = button.innerHTML;
  button.disabled = true;
  button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span>';
  try {
    const res = await Api.addToCart(button.dataset.add, 1);
    setCartBadge(res.data.totalItems);
    showToast(res.message || 'Added to cart', 'success');
    button.classList.add('is-added');
    button.innerHTML = '<i class="bi bi-check-lg"></i> Added';
    setTimeout(() => {
      button.classList.remove('is-added');
      button.innerHTML = original;
      button.disabled = false;
    }, 1200);
  } catch (err) {
    showToast(err.message, 'danger');
    button.innerHTML = original;
    button.disabled = false;
  }
}

document.addEventListener('click', (event) => {
  const addButton = event.target.closest('[data-add]');
  if (addButton) handleAddToCart(addButton);

  if (event.target.closest('[data-retry]') && typeof window.fkRetry === 'function') window.fkRetry();
});

// ---------- 5. Home page ----------

function initHomePage() {
  const searchForm = document.getElementById('heroSearch');
  const chipRow = document.getElementById('categoryRow');
  const dishGrid = document.getElementById('dishGrid');
  const dishTitle = document.getElementById('dishTitle');
  const featuredGrid = document.getElementById('featuredGrid');
  let activeCategory = '';
  let dishRequest = 0;

  // Hero search: go to the restaurants page, which runs the search through the API
  searchForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const text = document.getElementById('heroSearchInput').value.trim();
    window.location.href = text ? `restaurants.html?search=${encodeURIComponent(text)}` : 'restaurants.html';
  });

  // Category buttons: reload the dishes from the API (GET /api/foods?category=...)
  chipRow.innerHTML = categoryChipsHtml([ALL_CHIP, ...CATEGORIES], activeCategory);
  chipRow.addEventListener('click', (event) => {
    const chip = event.target.closest('.fk-chip');
    if (!chip) return;
    activeCategory = chip.dataset.value;
    chipRow.innerHTML = categoryChipsHtml([ALL_CHIP, ...CATEGORIES], activeCategory);
    loadDishes();
  });

  async function loadFeatured() {
    featuredGrid.innerHTML = skeletonCards(3);
    try {
      const res = await Api.getRestaurants({ featured: true, limit: 3 });
      featuredGrid.innerHTML = res.data.length
        ? res.data.map(restaurantCard).join('')
        : inGrid(emptyState({ icon: '🏪', title: 'No restaurants yet', text: 'Run "npm run seed" in the backend folder to add sample data.' }));
    } catch (err) {
      featuredGrid.innerHTML = inGrid(errorState(err.message, 'Could not load restaurants'));
      showToast(err.message, 'danger');
    }
  }

  async function loadDishes() {
    const myRequest = ++dishRequest; // ignore old responses if the user clicks quickly
    dishGrid.innerHTML = skeletonCards(8, FOOD_SKELETON_COLS);
    dishTitle.textContent = activeCategory ? `${categoryMeta(activeCategory).label} favourites` : 'Popular dishes';
    try {
      const params = activeCategory ? { category: activeCategory, limit: 8 } : { popular: true, limit: 8 };
      const res = await Api.getFoods(params);
      if (myRequest !== dishRequest) return;
      dishGrid.innerHTML = res.data.length
        ? res.data.map(foodCard).join('')
        : inGrid(emptyState({ icon: '🍽️', title: 'Nothing here yet', text: 'No dishes found in this category.' }));
    } catch (err) {
      if (myRequest !== dishRequest) return;
      dishGrid.innerHTML = inGrid(errorState(err.message, 'Could not load dishes'));
      showToast(err.message, 'danger');
    }
  }

  window.fkRetry = () => { loadFeatured(); loadDishes(); };
  loadFeatured();
  loadDishes();
}

// ---------- Start ----------
renderLayout();
refreshCartCount();
if (document.body.dataset.page === 'home') initHomePage();
