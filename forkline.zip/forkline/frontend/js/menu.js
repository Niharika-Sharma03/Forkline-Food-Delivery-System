/* ==========================================================
   menu.js — Menu page
   - menu.html?id=<restaurantId>  -> that restaurant's menu
        GET /api/restaurants/:id           (banner)
        GET /api/restaurants/:id/foods     (dishes, with ?category= and ?search=)
   - menu.html (no id)            -> every dish from every restaurant
        GET /api/foods?category=&search=
   ========================================================== */

(function () {
  const header = document.getElementById('menuHeader');
  const toolbar = document.getElementById('toolbar');
  const searchInput = document.getElementById('searchInput');
  const chipRow = document.getElementById('categoryChips');
  const grid = document.getElementById('foodGrid');
  const info = document.getElementById('resultInfo');

  const restaurantId = new URLSearchParams(window.location.search).get('id');
  const state = { search: '', category: '' };
  let categoryList = []; // chips shown above the dishes
  let foodRequest = 0;

  // ----- Header -----

  function drawAllDishesHeader() {
    document.title = 'Full menu — Forkline';
    header.innerHTML = `
      <div class="page-hero rounded-5 px-4">
        <h1>Full menu</h1>
        <p class="section-sub mb-0">Every dish from every restaurant. Pick a restaurant to see its own menu.
          <a href="restaurants.html" class="fw-bold">Browse restaurants</a></p>
      </div>`;
  }

  async function drawRestaurantHeader() {
    header.innerHTML = '<div class="sk" style="height:230px;border-radius:28px"></div>';
    const res = await Api.getRestaurant(restaurantId); // throws for an invalid / unknown id
    const r = res.data;
    document.title = `${r.name} — Forkline`;
    header.innerHTML = `
      <a href="restaurants.html" class="text-decoration-none fw-bold d-inline-block mb-3"><i class="bi bi-arrow-left"></i> All restaurants</a>
      <div class="menu-banner">
        <img src="${esc(r.image)}" alt="${esc(r.name)}">
        <div class="inner">
          <span class="cat-pill position-static d-inline-block">${esc(r.cuisine)}</span>
          <h1>${esc(r.name)}</h1>
          <div class="meta">
            <span><i class="bi bi-star-fill"></i> ${Number(r.rating).toFixed(1)}</span>
            <span><i class="bi bi-clock"></i> ${esc(r.deliveryTime)}</span>
            <span><i class="bi bi-geo-alt"></i> ${esc(r.location)}</span>
          </div>
        </div>
      </div>`;
  }

  // ----- Dishes -----

  function drawChips() {
    chipRow.innerHTML = categoryChipsHtml([ALL_CHIP, ...categoryList], state.category);
  }

  async function loadFoods(isFirstLoad = false) {
    const myRequest = ++foodRequest; // ignore old responses if the user types quickly
    grid.innerHTML = skeletonCards(8, FOOD_SKELETON_COLS);
    info.textContent = '';

    try {
      const params = { search: state.search, category: state.category };
      const res = restaurantId ? await Api.getRestaurantFoods(restaurantId, params) : await Api.getFoods(params);
      if (myRequest !== foodRequest) return;

      // On the first (unfiltered) load of a restaurant menu, build the chips
      // from the categories that restaurant really sells.
      if (isFirstLoad) {
        categoryList = restaurantId
          ? [...new Set(res.data.map((f) => f.category))].map(categoryMeta)
          : CATEGORIES;
        drawChips();
      }

      if (res.data.length === 0) {
        const filtering = state.search || state.category;
        grid.innerHTML = inGrid(
          emptyState({
            icon: filtering ? '🔍' : '🍽️',
            title: filtering ? 'No dishes match your search' : 'This menu is empty',
            text: filtering ? 'Try another word or choose a different category.' : 'Check back soon for new dishes.',
          })
        );
      } else {
        grid.innerHTML = res.data.map(foodCard).join('');
      }
      info.textContent = `${res.count} dish${res.count === 1 ? '' : 'es'}`;
    } catch (err) {
      if (myRequest !== foodRequest) return;
      grid.innerHTML = inGrid(errorState(err.message, 'Could not load the menu'));
      showToast(err.message, 'danger');
    }
  }

  // ----- Events -----

  searchInput.addEventListener(
    'input',
    debounce(() => {
      state.search = searchInput.value.trim();
      loadFoods();
    }, 400)
  );

  chipRow.addEventListener('click', (event) => {
    const chip = event.target.closest('.fk-chip');
    if (!chip) return;
    state.category = chip.dataset.value;
    drawChips();
    loadFoods();
  });

  // ----- Start -----

  async function start() {
    toolbar.classList.remove('d-none');
    try {
      if (restaurantId) await drawRestaurantHeader();
      else drawAllDishesHeader();
    } catch (err) {
      // Invalid id (400) or unknown restaurant (404) or server problem
      const notFound = err.status === 400 || err.status === 404;
      toolbar.classList.add('d-none');
      info.textContent = '';
      header.innerHTML = '';
      grid.innerHTML = inGrid(
        notFound
          ? emptyState({
              icon: '🧭',
              title: 'Restaurant not found',
              text: 'This restaurant link is not valid. Please choose a restaurant from the list.',
              actionHtml: '<a href="restaurants.html" class="btn fk-btn">Browse restaurants</a>',
            })
          : errorState(err.message, 'Could not load this restaurant')
      );
      showToast(err.message, 'danger');
      return;
    }
    loadFoods(true);
  }

  window.fkRetry = start;
  start();
})();
