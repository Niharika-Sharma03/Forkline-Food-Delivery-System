/* ==========================================================
   api.js — the ONLY file that talks to the backend.
   Every page calls the functions in the `Api` object below.
   They use fetch() with async/await and throw a friendly ApiError on failure.
   ========================================================== */

// If this page is opened through the Express server (http://localhost:5000) we use a
// relative URL. If it is opened with VS Code Live Server (another port), we call
// the backend on port 5000 directly (CORS is enabled in the backend).
const API_BASE =
  window.FORKLINE_API_BASE ||
  (window.location.port === '5000' ? '/api' : 'http://localhost:5000/api');

// An error with an HTTP status (0 = the server could not be reached)
class ApiError extends Error {
  constructor(message, status = 0, errors = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.errors = errors; // optional list of { field, message } from the backend
  }
}

// Turns { search: 'pizza', category: '' } into "?search=pizza" (empty values are skipped)
function buildQuery(params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value).trim() !== '') {
      query.append(key, String(value).trim());
    }
  });
  const text = query.toString();
  return text ? `?${text}` : '';
}

// The one function that actually calls fetch()
async function request(path, options = {}) {
  const init = { ...options };
  if (options.body) init.headers = { 'Content-Type': 'application/json' };

  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, init);
  } catch (networkError) {
    // fetch() only throws when the server cannot be reached at all
    throw new ApiError(
      'Cannot reach the Forkline server. Please make sure the backend is running (npm start) and try again.',
      0
    );
  }

  let body = null;
  try {
    body = await response.json();
  } catch (parseError) {
    // the response was not JSON; handled below
  }

  // HTTP response validation: 4xx / 5xx become errors with the backend's message
  if (!response.ok) {
    throw new ApiError(
      (body && body.message) || `Request failed (HTTP ${response.status})`,
      response.status,
      body && body.errors
    );
  }
  if (!body) throw new ApiError('The server sent an unexpected response.', response.status);

  return body; // { success, message?, count?, data }
}

const Api = {
  // ----- Restaurants -----
  getRestaurants: (params) => request(`/restaurants${buildQuery(params)}`),
  getRestaurant: (id) => request(`/restaurants/${encodeURIComponent(id)}`),
  getRestaurantFoods: (id, params) =>
    request(`/restaurants/${encodeURIComponent(id)}/foods${buildQuery(params)}`),

  // ----- Foods -----
  getFoods: (params) => request(`/foods${buildQuery(params)}`),

  // ----- Cart (stored in MongoDB) -----
  getCart: () => request('/cart'),
  addToCart: (foodId, quantity = 1) =>
    request('/cart/items', { method: 'POST', body: JSON.stringify({ foodId, quantity }) }),
  updateCartItem: (foodId, quantity) =>
    request(`/cart/items/${encodeURIComponent(foodId)}`, { method: 'PATCH', body: JSON.stringify({ quantity }) }),
  removeCartItem: (foodId) =>
    request(`/cart/items/${encodeURIComponent(foodId)}`, { method: 'DELETE' }),

  // ----- Orders -----
  placeOrder: (details) => request('/orders', { method: 'POST', body: JSON.stringify(details) }),
  getOrder: (orderRef) => request(`/orders/${encodeURIComponent(orderRef)}`),
};
