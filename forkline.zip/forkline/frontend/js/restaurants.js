/* ==========================================================
   restaurants.js — Restaurants page
   Search + cuisine filter both run on the BACKEND:
     GET /api/restaurants?search=pizza&cuisine=Indian
   ========================================================== */

(function () {
  const searchInput = document.getElementById('searchInput');
  const chipRow = document.getElementById('cuisineChips');
  const grid = document.getElementById('restaurantGrid');
  const info = document.getElementById('resultInfo');
  const dishSection = document.getElementById('dishSection');
  const dishGrid = document.getElementById('dishGrid');

  // Start from the URL, e.g. restaurants.html?search=pizza (coming from the home page search)
  const urlParams = new URLSearchParams(window.location.search);
  const state = { search: urlParams.get('search') || '', cuisine: urlParams.get('cuisine') || '' };
  let restaurantRequest = 0;
  let dishRequest = 0;

  searchInput.value = state.search;

  function drawChips() {
    chipRow.innerHTML = categoryChipsHtml([ALL_CHIP, ...CATEGORIES], state.cuisine);
  }

  // Keep the address bar in sync, so the page can be refreshed or shared
  function updateUrl() {
    const query = new URLSearchParams();
    if (state.search) query.set('search', state.search);
    if (state.cuisine) query.set('cuisine', state.cuisine);
    const text = query.toString();
    history.replaceState(null, '', text ? `?${text}` : window.location.pathname);
  }

  async function loadRestaurants() {
    const myRequest = ++restaurantRequest; // ignore old responses if the user types quickly
    grid.innerHTML = skeletonCards(6);
    info.textContent = '';
    updateUrl();
    loadMatchingDishes();

    try {
      const res = await Api.getRestaurants({ search: state.search, cuisine: state.cuisine });
      if (myRequest !== restaurantRequest) return;

      if (res.data.length === 0) {
        grid.innerHTML = inGrid(
          emptyState({
            icon: '🔍',
            title: 'No restaurants found',
            text: 'Try a different word or clear the filters to see everything.',
            actionHtml: '<button type="button" class="btn fk-btn" id="clearFilters">Clear filters</button>',
          })
        );
      } else {
        grid.innerHTML = res.data.map(restaurantCard).join('');
      }
      info.textContent = `${res.count} restaurant${res.count === 1 ? '' : 's'} found`;
    } catch (err) {
      if (myRequest !== restaurantRequest) return;
      grid.innerHTML = inGrid(errorState(err.message, 'Could not load restaurants'));
      showToast(err.message, 'danger');
    }
  }

  // While searching, also show dishes whose NAME matches (GET /api/foods?search=...)
  async function loadMatchingDishes() {
    const myRequest = ++dishRequest;
    if (!state.search) {
      dishSection.classList.add('d-none');
      return;
    }
    try {
      const res = await Api.getFoods({ search: state.search, limit: 8 });
      if (myRequest !== dishRequest) return;
      dishSection.classList.toggle('d-none', res.data.length === 0);
      dishGrid.innerHTML = res.data.map(foodCard).join('');
    } catch (err) {
      if (myRequest !== dishRequest) return;
      dishSection.classList.add('d-none'); // the restaurant list already reports the error
    }
  }

  // Debounced typing: waits 400 ms after the last key press before calling the API
  searchInput.addEventListener(
    'input',
    debounce(() => {
      state.search = searchInput.value.trim();
      loadRestaurants();
    }, 400)
  );

  chipRow.addEventListener('click', (event) => {
    const chip = event.target.closest('.fk-chip');
    if (!chip) return;
    state.cuisine = chip.dataset.value;
    drawChips();
    loadRestaurants();
  });

  grid.addEventListener('click', (event) => {
    if (event.target.closest('#clearFilters')) {
      state.search = '';
      state.cuisine = '';
      searchInput.value = '';
      drawChips();
      loadRestaurants();
    }
  });

  window.fkRetry = loadRestaurants;
  drawChips();
  loadRestaurants();
})();
