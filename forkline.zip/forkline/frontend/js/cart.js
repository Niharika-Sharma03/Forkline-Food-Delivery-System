/* ==========================================================
   cart.js — Shopping cart page
   Every change is saved in MongoDB through the API and the page is
   redrawn from the cart that the backend sends back:
     GET    /api/cart
     PATCH  /api/cart/items/:foodId   { quantity }
     DELETE /api/cart/items/:foodId
   The totals shown here are calculated by the BACKEND, not in the browser.
   ========================================================== */

(function () {
  const content = document.getElementById('cartContent');
  const subtitle = document.getElementById('cartSubtitle');
  const MAX_QTY = 10; // same limit as the backend

  let cart = null; // { items, totalItems, totalAmount }
  let busy = false; // blocks double clicks while a request is running

  function itemRow(item, index) {
    const unavailableBadge = item.isAvailable
      ? ''
      : '<span class="badge text-bg-danger ms-1">Unavailable — please remove</span>';
    return `
      <div class="cart-item fade-up" style="--i:${index}">
        <img src="${esc(item.image)}" alt="${esc(item.name)}">
        <div>
          <h3>${esc(item.name)}</h3>
          <p class="sub">${esc(item.restaurantName)} · ${esc(item.category)}</p>
          <span class="unit">${formatPrice(item.price)} each</span>${unavailableBadge}
        </div>
        <div class="qty-stepper" role="group" aria-label="Quantity of ${esc(item.name)}">
          <button type="button" data-action="dec" data-id="${esc(item.foodId)}" ${item.quantity <= 1 ? 'disabled' : ''} aria-label="Decrease quantity"><i class="bi bi-dash-lg"></i></button>
          <span class="qty">${item.quantity}</span>
          <button type="button" data-action="inc" data-id="${esc(item.foodId)}" ${item.quantity >= MAX_QTY ? 'disabled' : ''} aria-label="Increase quantity"><i class="bi bi-plus-lg"></i></button>
        </div>
        <div class="line-total">${formatPrice(item.subtotal)}</div>
        <button type="button" class="remove-btn" data-action="remove" data-id="${esc(item.foodId)}" aria-label="Remove ${esc(item.name)}"><i class="bi bi-trash3"></i></button>
      </div>`;
  }

  function render() {
    setCartBadge(cart.totalItems);

    if (cart.items.length === 0) {
      subtitle.textContent = 'Nothing here yet.';
      content.innerHTML = emptyState({
        icon: '🛒',
        title: 'Your cart is empty',
        text: 'Looks like you have not added anything yet. Hungry? Let us fix that.',
        actionHtml: '<a href="restaurants.html" class="btn fk-btn"><i class="bi bi-shop"></i> Start shopping</a>',
      });
      return;
    }

    const hasUnavailable = cart.items.some((item) => !item.isAvailable);
    subtitle.textContent = `${cart.totalItems} item${cart.totalItems === 1 ? '' : 's'} in your cart`;

    content.innerHTML = `
      <div class="row g-4">
        <div class="col-lg-8">${cart.items.map(itemRow).join('')}</div>
        <div class="col-lg-4">
          <aside class="summary-card">
            <h3>Order summary</h3>
            <div class="summary-row"><span>Total items</span><span>${cart.totalItems}</span></div>
            <div class="summary-row total"><span>Total</span><span>${formatPrice(cart.totalAmount)}</span></div>
            ${hasUnavailable ? '<p class="text-danger small mt-2 mb-0">Remove unavailable items to continue.</p>' : ''}
            <a href="checkout.html" class="btn fk-btn w-100 mt-3 ${hasUnavailable ? 'disabled' : ''}"><i class="bi bi-bag-check"></i> Place Order</a>
            <a href="restaurants.html" class="btn fk-btn-outline w-100 mt-2">Continue Shopping</a>
          </aside>
        </div>
      </div>`;
  }

  async function loadCart() {
    content.innerHTML = `<div class="row g-4"><div class="col-lg-8">${skeletonCards(3, 'col-12')}</div></div>`;
    try {
      const res = await Api.getCart();
      cart = res.data;
      render();
    } catch (err) {
      content.innerHTML = errorState(err.message, 'Could not load your cart');
      showToast(err.message, 'danger');
    }
  }

  // Runs an API call (change quantity / remove), then redraws with the new cart from the backend
  async function runCartAction(apiCall, successMessage) {
    if (busy) return;
    busy = true;
    content.classList.add('is-busy');
    try {
      const res = await apiCall();
      cart = res.data;
      render();
      if (successMessage) showToast(successMessage, 'success');
    } catch (err) {
      showToast(err.message, 'danger');
      // The item may have vanished (404) or the server state changed, so sync with the database
      if (err.status === 404 || err.status === 409) await loadCart();
    } finally {
      busy = false;
      content.classList.remove('is-busy');
    }
  }

  // One listener for all +, - and remove buttons (event delegation)
  content.addEventListener('click', (event) => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const foodId = button.dataset.id;
    const item = cart.items.find((i) => String(i.foodId) === foodId);
    if (!item) return;

    if (button.dataset.action === 'inc') {
      runCartAction(() => Api.updateCartItem(foodId, item.quantity + 1));
    } else if (button.dataset.action === 'dec') {
      runCartAction(() => Api.updateCartItem(foodId, item.quantity - 1));
    } else if (button.dataset.action === 'remove') {
      runCartAction(() => Api.removeCartItem(foodId), `${item.name} removed from cart`);
    }
  });

  window.fkRetry = loadCart;
  loadCart();
})();
