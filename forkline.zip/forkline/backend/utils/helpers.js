// utils/helpers.js
// Small helper functions shared by the controllers.

// Turn a query-string value into a trimmed string ("" if missing or not a string).
// (A request like ?search=a&search=b would give an array, which we ignore.)
function asString(value) {
  return typeof value === 'string' ? value.trim() : '';
}

// Escape characters that have a special meaning in regular expressions,
// so a user typing "(" or "c++" can never break the search.
function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// A MongoDB ObjectId is exactly 24 hexadecimal characters.
function isValidId(id) {
  return typeof id === 'string' && /^[0-9a-fA-F]{24}$/.test(id);
}

// Convert a value to a whole number. Returns NaN for anything else (1.5, "abc", true ...).
function toInt(value) {
  if (typeof value === 'number') return Number.isInteger(value) ? value : NaN;
  if (typeof value === 'string' && /^-?\d+$/.test(value.trim())) return parseInt(value, 10);
  return NaN;
}

// Read ?limit=... safely (between 1 and max)
function parseLimit(value, fallback = 100, max = 100) {
  const n = toInt(value);
  if (Number.isNaN(n) || n < 1) return fallback;
  return Math.min(n, max);
}

// Avoid floating point surprises such as 0.1 + 0.2
function roundMoney(amount) {
  return Math.round(amount * 100) / 100;
}

module.exports = { asString, escapeRegex, isValidId, toInt, parseLimit, roundMoney };
