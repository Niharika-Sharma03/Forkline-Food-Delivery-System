// routes/foodRoutes.js  (mounted at /api/foods)

const express = require('express');
const controller = require('../controllers/foodController');

const router = express.Router();

router.get('/', controller.getFoods);

module.exports = router;
