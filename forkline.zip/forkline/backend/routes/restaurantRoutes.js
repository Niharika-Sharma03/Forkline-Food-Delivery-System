// routes/restaurantRoutes.js  (mounted at /api/restaurants)

const express = require('express');
const validateId = require('../middleware/validateObjectId');
const controller = require('../controllers/restaurantController');

const router = express.Router();

router.get('/', controller.getRestaurants);
router.get('/:id', validateId('id', 'restaurant'), controller.getRestaurantById);
router.get('/:id/foods', validateId('id', 'restaurant'), controller.getRestaurantFoods);

module.exports = router;
