// routes/orderRoutes.js  (mounted at /api/orders)

const express = require('express');
const controller = require('../controllers/orderController');

const router = express.Router();

router.post('/', controller.createOrder);
router.get('/:orderRef', controller.getOrderByRef);

module.exports = router;
