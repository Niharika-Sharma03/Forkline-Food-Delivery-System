// routes/cartRoutes.js  (mounted at /api/cart)

const express = require('express');
const validateId = require('../middleware/validateObjectId');
const controller = require('../controllers/cartController');

const router = express.Router();

router.get('/', controller.getCart);
router.post('/items', controller.addItem);
router.patch('/items/:foodId', validateId('foodId', 'food'), controller.updateItem);
router.delete('/items/:foodId', validateId('foodId', 'food'), controller.removeItem);

module.exports = router;
