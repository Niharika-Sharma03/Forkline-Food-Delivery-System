// middleware/errorHandler.js
// Every error in the API ends up here and is sent back in the same JSON shape:
//   { "success": false, "message": "...", "errors": [ ... optional ... ] }

// An error we throw on purpose, with an HTTP status code
class AppError extends Error {
  constructor(message, statusCode = 500, errors = null) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors; // optional list of field errors
    this.isOperational = true;
  }
}

// Runs when no route matched the request
function notFound(req, res, next) {
  next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  let status = err.statusCode || 500;
  let message = err.message || 'Something went wrong';
  let errors = err.errors || null;

  if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Request body is not valid JSON';
  } else if (err.type === 'entity.too.large') {
    status = 413;
    message = 'Request body is too large';
  } else if (err.name === 'CastError') {
    status = 400;
    message = `Invalid value for "${err.path}"`;
  } else if (err.name === 'ValidationError' && err.errors) {
    status = 400;
    message = 'Validation failed';
    errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
  } else if (err.code === 11000) {
    status = 409;
    message = 'This record already exists';
  } else if (err.name === 'VersionError') {
    status = 409;
    message = 'The cart was changed by another request. Please try again.';
  } else if (/ServerSelection|MongoNetwork|MongoNotConnected/.test(err.name || '')) {
    status = 503;
    message = 'Cannot reach the database. Please make sure MongoDB is running.';
  } else if (!err.isOperational) {
    // A real bug. Log the details for the developer, hide them from the user.
    console.error('Unexpected error:', err);
    status = 500;
    message = 'Internal server error';
  }

  res.status(status).json({ success: false, message, ...(errors ? { errors } : {}) });
}

module.exports = { AppError, notFound, errorHandler };
