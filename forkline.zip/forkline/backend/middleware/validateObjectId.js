// middleware/validateObjectId.js
// Usage in a route:  router.get('/:id', validateId('id', 'restaurant'), handler)
// Rejects malformed IDs with a 400 error before we ever touch the database.

const { AppError } = require('./errorHandler');
const { isValidId } = require('../utils/helpers');

module.exports = function validateId(param = 'id', label = 'ID') {
  return (req, res, next) => {
    if (!isValidId(req.params[param])) {
      return next(new AppError(`Invalid ${label} ID`, 400));
    }
    next();
  };
};
