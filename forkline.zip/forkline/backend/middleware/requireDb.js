// middleware/requireDb.js
// Stops API requests early with a clear 503 message when MongoDB is not connected.
// (Without this, Mongoose would silently wait and the browser would hang.)

const mongoose = require('mongoose');
const { AppError } = require('./errorHandler');

// readyState 1 means "connected"
module.exports = function requireDb(req, res, next) {
  if (mongoose.connection.readyState !== 1) {
    return next(
      new AppError('Database is not connected. Please make sure MongoDB is running and try again.', 503)
    );
  }
  next();
};
