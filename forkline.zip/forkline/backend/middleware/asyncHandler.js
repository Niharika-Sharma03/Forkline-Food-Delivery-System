// middleware/asyncHandler.js
// Wraps an async controller so that any error is passed to Express's error
// handler automatically. This lets controllers stay free of repeated try/catch.

module.exports = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
