// models/Cart.js  ->  MongoDB collection: "carts"
// There is one cart document per user. The project has no login, so the
// userId is always the fixed demo user from the .env file.
// The cart only stores foodId + quantity. Names and prices are looked up from
// the "foods" collection every time, so a price can never be faked.

const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema(
  {
    foodId: { type: mongoose.Schema.Types.ObjectId, ref: 'Food', required: true },
    quantity: { type: Number, required: true, min: 1, max: 10, default: 1 },
  },
  { _id: false }
);

const cartSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, unique: true, trim: true },
    items: { type: [cartItemSchema], default: [] },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Cart', cartSchema);
