// models/Food.js  ->  MongoDB collection: "foods"

const mongoose = require('mongoose');

// The six categories used by the filter buttons on the website
const CATEGORIES = ['Pizza', 'Burger', 'Indian', 'Chinese', 'Dessert', 'Beverage'];

const foodSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Food name is required'], trim: true },
    description: { type: String, trim: true, default: '' },
    price: {
      type: Number, // in Indian Rupees
      required: [true, 'Price is required'],
      min: [1, 'Price must be at least ₹1'],
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: { values: CATEGORIES, message: '{VALUE} is not a valid category' },
    },
    image: { type: String, trim: true, default: '' },
    // Link to the restaurant that sells this dish
    restaurantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Restaurant',
      required: [true, 'restaurantId is required'],
      index: true,
    },
    // Set to false (for example in MongoDB Compass) to make a dish "unavailable".
    // Unavailable dishes cannot be added to the cart or ordered.
    isAvailable: { type: Boolean, default: true },
    // Used by the homepage "Popular dishes" section
    isPopular: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// A restaurant cannot have two dishes with the same name
foodSchema.index({ restaurantId: 1, name: 1 }, { unique: true });

const Food = mongoose.model('Food', foodSchema);
Food.CATEGORIES = CATEGORIES;

module.exports = Food;
