// models/Restaurant.js  ->  MongoDB collection: "restaurants"

const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Restaurant name is required'],
      trim: true,
      unique: true, // also keeps the seed script from creating duplicates
    },
    // Written as a short text such as "Pizza, Italian". Filtering uses "contains".
    cuisine: {
      type: String,
      required: [true, 'Cuisine is required'],
      trim: true,
    },
    rating: { type: Number, min: 0, max: 5, default: 4 },
    deliveryTime: {
      type: String, // e.g. "25-30 min"
      required: [true, 'Delivery time is required'],
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Location is required'],
      trim: true,
    },
    image: { type: String, trim: true, default: '' },
    // Used by the homepage "Featured restaurants" section
    isFeatured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Restaurant', restaurantSchema);
