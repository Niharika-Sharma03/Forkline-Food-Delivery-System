// models/Order.js  ->  MongoDB collection: "orders"
// Each order keeps a SNAPSHOT of the dishes (name + price at that moment),
// so old orders stay correct even if the menu changes later.

const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema(
  {
    foodId: { type: mongoose.Schema.Types.ObjectId, ref: 'Food', required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true }, // price of ONE item, taken from the database
    quantity: { type: Number, required: true, min: 1 },
    subtotal: { type: Number, required: true }, // price x quantity
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema({
  orderRef: { type: String, required: true, unique: true }, // e.g. FLK-261021-A3F9C2
  userId: { type: String, required: true },
  customerName: { type: String, required: [true, 'Customer name is required'], trim: true },
  phone: { type: String, required: [true, 'Phone number is required'], trim: true },
  address: { type: String, required: [true, 'Delivery address is required'], trim: true },
  items: {
    type: [orderItemSchema],
    validate: [(items) => items.length > 0, 'An order needs at least one item'],
  },
  totalAmount: { type: Number, required: true, min: 0 },
  orderStatus: {
    type: String,
    enum: ['Placed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'],
    default: 'Placed',
  },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Order', orderSchema);
