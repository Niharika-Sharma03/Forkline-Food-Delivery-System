// seed.js  -  fills MongoDB with sample restaurants and food.
//
//   npm run seed          -> safe to run many times (updates existing records, never duplicates)
//   npm run seed:reset    -> first deletes restaurants, foods and carts, then inserts fresh data
//
// Match records are identified by:  restaurant name  /  restaurant + food name.

require('dotenv').config();
const mongoose = require('mongoose');
const Restaurant = require('./models/Restaurant');
const Food = require('./models/Food');
const Cart = require('./models/Cart');

// Builds an Unsplash image URL from a photo id
const img = (id) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=900&q=80`;

const data = [
  {
    name: 'Napoli Wood Fire',
    cuisine: 'Pizza, Italian',
    rating: 4.6,
    deliveryTime: '25-30 min',
    location: 'Phase 7, Mohali',
    image: img('1513104890138-7c749659a591'),
    isFeatured: true,
    foods: [
      { name: 'Margherita Classica', category: 'Pizza', price: 299, isPopular: true, image: img('1574071318508-1cdbab80d002'), description: 'Hand-stretched crust, San Marzano tomato sauce, fresh mozzarella and basil.' },
      { name: 'Pepperoni Fire', category: 'Pizza', price: 399, image: img('1628840042765-356cda07504e'), description: 'Crispy pepperoni, molten cheese and a drizzle of chilli honey.' },
      { name: 'Paneer Tikka Pizza', category: 'Pizza', price: 349, isPopular: true, image: img('1565299624946-b28f40a0ae38'), description: 'Tandoori paneer, onions, capsicum and mint mayo on a smoky base.' },
      { name: 'Farmhouse Veggie Feast', category: 'Pizza', price: 379, image: img('1604382354936-07c5d9983bd3'), description: 'Loaded with mushrooms, olives, sweet corn, bell peppers and tomatoes.' },
      { name: 'Tiramisu Cup', category: 'Dessert', price: 189, image: img('1571877227200-a0d98ea607e9'), description: 'Coffee-soaked sponge layered with creamy mascarpone and cocoa.' },
    ],
  },
  {
    name: 'Smokestack Burgers',
    cuisine: 'Burgers, American',
    rating: 4.4,
    deliveryTime: '20-25 min',
    location: 'Sector 70, Mohali',
    image: img('1568901346375-23c9450c58cd'),
    isFeatured: true,
    foods: [
      { name: 'Classic Smash Burger', category: 'Burger', price: 229, isPopular: true, image: img('1568901346375-23c9450c58cd'), description: 'Smashed patty, American cheese, pickles and house sauce in a toasted brioche bun.' },
      { name: 'Double Cheese Stack', category: 'Burger', price: 299, image: img('1550547660-d9450f859349'), description: 'Two patties, double cheddar, caramelised onions and smoky mayo.' },
      { name: 'Crispy Veg Burger', category: 'Burger', price: 179, image: img('1520072959219-c595dc870360'), description: 'Golden vegetable and potato patty with lettuce, tomato and creamy dressing.' },
      { name: 'Spicy Chicken Zinger', category: 'Burger', price: 249, isPopular: true, image: img('1606755962773-d324e0a13086'), description: 'Extra-crunchy fried chicken fillet with fiery peri-peri sauce.' },
      { name: 'Chocolate Thick Shake', category: 'Beverage', price: 169, image: img('1572490122747-3968b75cc699'), description: 'Thick, creamy milkshake made with real chocolate and vanilla ice cream.' },
    ],
  },
  {
    name: 'Maharaja Kitchen',
    cuisine: 'North Indian, Mughlai',
    rating: 4.7,
    deliveryTime: '30-40 min',
    location: 'Sector 17, Chandigarh',
    image: img('1585937421612-70a008356fbe'),
    isFeatured: true,
    foods: [
      { name: 'Butter Chicken', category: 'Indian', price: 349, isPopular: true, image: img('1603894584373-5ac82b2ae398'), description: 'Tandoor-grilled chicken simmered in a rich, buttery tomato gravy.' },
      { name: 'Paneer Butter Masala', category: 'Indian', price: 299, image: img('1631452180519-c014fe946bc7'), description: 'Soft paneer cubes in a velvety cashew and tomato sauce.' },
      { name: 'Dal Makhani', category: 'Indian', price: 249, image: img('1546833999-b9f581a1996d'), description: 'Black lentils slow-cooked overnight with cream and butter.' },
      { name: 'Hyderabadi Veg Biryani', category: 'Indian', price: 279, isPopular: true, image: img('1563379091339-03b21ab4a4f8'), description: 'Fragrant basmati layered with spiced vegetables, saffron and fried onions.' },
      { name: 'Gulab Jamun (2 pcs)', category: 'Dessert', price: 119, image: img('1666190092159-3171cf0fbb12'), description: 'Warm milk dumplings soaked in cardamom-scented sugar syrup.' },
    ],
  },
  {
    name: 'Dragon Wok',
    cuisine: 'Chinese, Asian',
    rating: 4.3,
    deliveryTime: '25-35 min',
    location: 'Sector 35, Chandigarh',
    image: img('1512058564366-18510be2db19'),
    isFeatured: true,
    foods: [
      { name: 'Veg Hakka Noodles', category: 'Chinese', price: 189, isPopular: true, image: img('1585032226651-759b368d7246'), description: 'Wok-tossed noodles with crunchy vegetables and soy-garlic sauce.' },
      { name: 'Chilli Paneer Dry', category: 'Chinese', price: 249, image: img('1567188040759-fb8a883dc6d8'), description: 'Crispy paneer tossed with capsicum, spring onion and green chillies.' },
      { name: 'Chicken Manchurian Gravy', category: 'Chinese', price: 269, image: img('1525755662778-989d0524087e'), description: 'Juicy chicken balls in a tangy, spicy Indo-Chinese gravy.' },
      { name: 'Veg Steamed Momos', category: 'Chinese', price: 149, isPopular: true, image: img('1534422298391-e4f8c172dddb'), description: 'Eight delicate dumplings served with fiery red chilli chutney.' },
      { name: 'Hot & Sour Soup', category: 'Chinese', price: 129, image: img('1547592166-23ac45744acd'), description: 'Peppery, tangy soup with mushrooms, tofu and fresh vegetables.' },
    ],
  },
  {
    name: 'Sugar & Spice Patisserie',
    cuisine: 'Desserts, Bakery',
    rating: 4.8,
    deliveryTime: '20-30 min',
    location: 'Phase 5, Mohali',
    image: img('1578985545062-69928b1d9587'),
    isFeatured: false,
    foods: [
      { name: 'Belgian Chocolate Brownie', category: 'Dessert', price: 149, isPopular: true, image: img('1606313564200-e75d5e30476c'), description: 'Fudgy brownie made with dark Belgian chocolate and walnuts.' },
      { name: 'Red Velvet Pastry', category: 'Dessert', price: 129, image: img('1586788680434-30d324b2d46f'), description: 'Soft red velvet layers with silky cream cheese frosting.' },
      { name: 'Blueberry Cheesecake', category: 'Dessert', price: 199, image: img('1533134242443-d4fd215305ad'), description: 'Baked cheesecake on a buttery biscuit base with blueberry compote.' },
      { name: 'Choco Lava Cake', category: 'Dessert', price: 139, isPopular: true, image: img('1624353365286-3f8d62daad51'), description: 'Warm chocolate cake with a gooey molten centre.' },
      { name: 'Fresh Fruit Cream Waffle', category: 'Dessert', price: 179, image: img('1562376552-0d160a2f238d'), description: 'Crisp waffle topped with whipped cream, seasonal fruit and maple syrup.' },
    ],
  },
  {
    name: 'Brew & Bloom',
    cuisine: 'Beverages, Cafe',
    rating: 4.5,
    deliveryTime: '15-20 min',
    location: 'Sector 8, Chandigarh',
    image: img('1461023058943-07fcbe16d735'),
    isFeatured: false,
    foods: [
      { name: 'Cold Coffee Frappe', category: 'Beverage', price: 149, isPopular: true, image: img('1517701604599-bb29b565090c'), description: 'Blended iced coffee topped with whipped cream and chocolate drizzle.' },
      { name: 'Fresh Mint Mojito', category: 'Beverage', price: 119, image: img('1551024709-8f23befc6f87'), description: 'Sparkling cooler with crushed mint, lime and a hint of sweetness.' },
      { name: 'Mango Smoothie', category: 'Beverage', price: 139, image: img('1623065422902-30a2d299bbe4'), description: 'Thick smoothie blended from ripe Alphonso mango and chilled yogurt.' },
      { name: 'Masala Chai (Kulhad)', category: 'Beverage', price: 59, isPopular: true, image: img('1571934811356-5cc061b6821f'), description: 'Strong, spiced tea served in a traditional clay kulhad.' },
      { name: 'Blue Lagoon Cooler', category: 'Beverage', price: 129, image: img('1536935338788-846bb9981813'), description: 'Citrusy blue curaçao-flavoured mocktail with lemon and soda.' },
    ],
  },
];

async function seed() {
  if (!process.env.MONGODB_URI) {
    console.error('❌ MONGODB_URI is missing. Copy .env.example to .env first.');
    process.exit(1);
  }

  await mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 5000 });
  console.log(`Connected to database "${mongoose.connection.name}"`);

  // Build unique indexes first so upserts cannot create duplicates
  await Restaurant.init();
  await Food.init();

  if (process.argv.includes('--reset')) {
    await Food.deleteMany({});
    await Restaurant.deleteMany({});
    await Cart.deleteMany({}); // carts point to foods that no longer exist
    console.log('Old restaurants, foods and carts deleted (orders are kept).');
  }

  let restaurantsCreated = 0;
  let foodsCreated = 0;

  for (const { foods, ...restaurantData } of data) {
    // Create the restaurant, or update it if a restaurant with this name already exists
    const found = await Restaurant.findOne({ name: restaurantData.name });
    let restaurant;
    if (found) {
      found.set(restaurantData);
      restaurant = await found.save();
    } else {
      restaurant = await Restaurant.create(restaurantData);
      restaurantsCreated++;
    }

    for (const food of foods) {
      // isAvailable is only set on first insert, so a dish you switched off in
      // MongoDB Compass stays switched off when you run the seed again.
      const result = await Food.updateOne(
        { restaurantId: restaurant._id, name: food.name },
        {
          $set: { ...food, restaurantId: restaurant._id },
          $setOnInsert: { isAvailable: true },
        },
        { upsert: true, runValidators: true }
      );
      if (result.upsertedCount > 0) foodsCreated++;
    }
  }

  const totalRestaurants = await Restaurant.countDocuments();
  const totalFoods = await Food.countDocuments();

  console.log(`✅ Restaurants: ${restaurantsCreated} new, ${totalRestaurants} total in database`);
  console.log(`✅ Foods:       ${foodsCreated} new, ${totalFoods} total in database`);
}

seed()
  .catch((err) => {
    console.error('❌ Seeding failed:', err.message);
    process.exitCode = 1;
  })
  .finally(() => mongoose.disconnect());
