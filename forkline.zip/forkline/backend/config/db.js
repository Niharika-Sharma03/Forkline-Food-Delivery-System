// config/db.js
// Connects Mongoose to MongoDB. If MongoDB is not running, we do NOT crash:
// we print a clear message and retry every 5 seconds. While the database is
// down, the API answers with HTTP 503 (see middleware/requireDb.js), and the
// frontend shows a friendly error message.

const mongoose = require('mongoose');

const RETRY_DELAY_MS = 5000;

async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.error('❌ MONGODB_URI is missing. Copy .env.example to .env first.');
    return;
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`✅ MongoDB connected: ${mongoose.connection.name}`);
  } catch (err) {
    console.error(`❌ MongoDB connection failed: ${err.message}`);
    console.error(`   Is MongoDB running? Retrying in ${RETRY_DELAY_MS / 1000} seconds...`);
    setTimeout(connectDB, RETRY_DELAY_MS);
  }
}

// Helpful log lines if the connection drops later
mongoose.connection.on('disconnected', () => console.warn('⚠️  MongoDB disconnected'));
mongoose.connection.on('reconnected', () => console.log('✅ MongoDB reconnected'));

module.exports = connectDB;
