// server.js  -  entry point of the Forkline backend
// Start it with:  npm start     (or  npm run dev  to auto-restart on changes)

require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');

const connectDB = require('./config/db');
const requireDb = require('./middleware/requireDb');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

// ---------- Global middleware ----------

// CORS lets the frontend (for example Live Server on port 5500) call this API on port 5000.
const allowedOrigins = (process.env.CORS_ORIGIN || '*').split(',').map((o) => o.trim());
app.use(cors({ origin: allowedOrigins.includes('*') ? true : allowedOrigins }));

// Read JSON request bodies (limit protects against huge requests)
app.use(express.json({ limit: '10kb' }));

// ---------- Routes ----------

// Health check: works even when MongoDB is down, handy for debugging
app.get('/api/health', (req, res) => {
  const mongoose = require('mongoose');
  const connected = mongoose.connection.readyState === 1;
  res.status(connected ? 200 : 503).json({
    success: connected,
    server: 'running',
    database: connected ? 'connected' : 'disconnected',
  });
});

// Every other /api request needs a working database connection
app.use('/api', requireDb);

app.use('/api/restaurants', require('./routes/restaurantRoutes'));
app.use('/api/foods', require('./routes/foodRoutes'));
app.use('/api/cart', require('./routes/cartRoutes'));
app.use('/api/orders', require('./routes/orderRoutes'));

// Unknown /api URLs -> JSON 404
app.use('/api', notFound);

// Optional: also serve the frontend folder from this server, so the whole app
// can be opened at http://localhost:5000 (no Live Server needed).
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// All errors end up here
app.use(errorHandler);

// ---------- Start ----------

app.listen(PORT, () => {
  console.log(`🍴 Forkline API running on http://localhost:${PORT}`);
  console.log(`   Health check: http://localhost:${PORT}/api/health`);
  connectDB(); // connect (and keep retrying) without blocking the server
});

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled promise rejection:', reason);
});
