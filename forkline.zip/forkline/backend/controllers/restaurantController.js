// controllers/restaurantController.js
// Handles:  GET /api/restaurants
//           GET /api/restaurants/:id
//           GET /api/restaurants/:id/foods   (the menu of one restaurant)

const Restaurant = require('../models/Restaurant');
const Food = require('../models/Food');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const { asString, escapeRegex, parseLimit } = require('../utils/helpers');

// GET /api/restaurants?search=pizza&cuisine=Indian&featured=true&limit=6
// - search   : matches the restaurant name OR cuisine (case-insensitive)
// - cuisine  : keeps restaurants whose cuisine contains this word
// - featured : "true" returns only featured restaurants (homepage)
exports.getRestaurants = asyncHandler(async (req, res) => {
  const search = asString(req.query.search);
  const cuisine = asString(req.query.cuisine);
  const filter = {};

  if (search) {
    const pattern = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ name: pattern }, { cuisine: pattern }];
  }
  if (cuisine && cuisine.toLowerCase() !== 'all') {
    filter.cuisine = new RegExp(escapeRegex(cuisine), 'i');
  }
  if (req.query.featured === 'true') {
    filter.isFeatured = true;
  }

  const restaurants = await Restaurant.find(filter)
    .sort({ rating: -1, name: 1 })
    .limit(parseLimit(req.query.limit));

  res.json({ success: true, count: restaurants.length, data: restaurants });
});

// GET /api/restaurants/:id
exports.getRestaurantById = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findById(req.params.id);
  if (!restaurant) throw new AppError('Restaurant not found', 404);

  res.json({ success: true, data: restaurant });
});

// GET /api/restaurants/:id/foods?category=Pizza&search=cheese
exports.getRestaurantFoods = asyncHandler(async (req, res) => {
  const restaurant = await Restaurant.findById(req.params.id);
  if (!restaurant) throw new AppError('Restaurant not found', 404);

  const category = asString(req.query.category);
  const search = asString(req.query.search);
  const filter = { restaurantId: restaurant._id };

  if (category && category.toLowerCase() !== 'all') {
    filter.category = new RegExp(`^${escapeRegex(category)}$`, 'i');
  }
  if (search) {
    filter.name = new RegExp(escapeRegex(search), 'i');
  }

  const foods = await Food.find(filter)
    .populate('restaurantId', 'name location')
    .sort({ category: 1, name: 1 });

  res.json({ success: true, count: foods.length, data: foods });
});
