// controllers/cartController.js
// Handles:  GET    /api/cart
//           POST   /api/cart/items
//           PATCH  /api/cart/items/:foodId
//           DELETE /api/cart/items/:foodId
//
// The cart in MongoDB only stores foodId + quantity. Every response is built
// by looking up the CURRENT food details and prices, and the totals are
// calculated here on the server.

const Cart = require('../models/Cart');
const Food = require('../models/Food');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const { isValidId, toInt, roundMoney } = require('../utils/helpers');

const MAX_QTY = 10; // maximum quantity of one dish

// The demo user (there is no login in this project)
const getUserId = () => process.env.DEMO_USER_ID || 'demo-user';

// Checks that a quantity is a whole number from 1 to MAX_QTY
function parseQuantity(value) {
  const qty = toInt(value);
  if (Number.isNaN(qty) || qty < 1 || qty > MAX_QTY) {
    throw new AppError(`Quantity must be a whole number between 1 and ${MAX_QTY}`, 400);
  }
  return qty;
}

// Builds the cart that is sent to the frontend:
// { items: [ { foodId, name, price, quantity, subtotal, ... } ], totalItems, totalAmount }
async function buildCartView(userId) {
  const cart = await Cart.findOne({ userId });
  if (!cart || cart.items.length === 0) {
    return { items: [], totalItems: 0, totalAmount: 0 };
  }

  const foodIds = cart.items.map((line) => line.foodId);
  const foods = await Food.find({ _id: { $in: foodIds } }).populate('restaurantId', 'name');
  const foodById = new Map(foods.map((food) => [String(food._id), food]));

  const items = [];
  const staleIds = []; // dishes that were deleted from the menu after being added
  let totalItems = 0;
  let totalAmount = 0;

  for (const line of cart.items) {
    const food = foodById.get(String(line.foodId));
    if (!food) {
      staleIds.push(line.foodId);
      continue;
    }
    const subtotal = roundMoney(food.price * line.quantity);
    items.push({
      foodId: food._id,
      name: food.name,
      image: food.image,
      category: food.category,
      restaurantName: food.restaurantId ? food.restaurantId.name : '',
      isAvailable: food.isAvailable,
      price: food.price,
      quantity: line.quantity,
      subtotal,
    });
    totalItems += line.quantity;
    totalAmount += subtotal;
  }

  // Clean up dishes that no longer exist
  if (staleIds.length > 0) {
    await Cart.updateOne({ userId }, { $pull: { items: { foodId: { $in: staleIds } } } });
  }

  return { items, totalItems, totalAmount: roundMoney(totalAmount) };
}

// GET /api/cart
exports.getCart = asyncHandler(async (req, res) => {
  const cart = await buildCartView(getUserId());
  res.json({ success: true, data: cart });
});

// POST /api/cart/items      body: { "foodId": "...", "quantity": 1 }
exports.addItem = asyncHandler(async (req, res) => {
  const body = req.body || {};
  const quantity = body.quantity === undefined ? 1 : parseQuantity(body.quantity);

  if (!isValidId(body.foodId)) throw new AppError('Invalid food ID', 400);

  const food = await Food.findById(body.foodId);
  if (!food) throw new AppError('Food item not found', 404);
  if (!food.isAvailable) throw new AppError(`${food.name} is currently unavailable`, 409);

  const userId = getUserId();
  let cart = await Cart.findOne({ userId });
  if (!cart) cart = new Cart({ userId, items: [] });

  const existing = cart.items.find((line) => String(line.foodId) === String(food._id));
  if (existing) {
    if (existing.quantity + quantity > MAX_QTY) {
      throw new AppError(`You can order at most ${MAX_QTY} of the same item`, 400);
    }
    existing.quantity += quantity;
  } else {
    cart.items.push({ foodId: food._id, quantity });
  }
  await cart.save();

  const view = await buildCartView(userId);
  res.status(201).json({ success: true, message: `${food.name} added to cart`, data: view });
});

// PATCH /api/cart/items/:foodId      body: { "quantity": 3 }
exports.updateItem = asyncHandler(async (req, res) => {
  const quantity = parseQuantity((req.body || {}).quantity);

  const userId = getUserId();
  const cart = await Cart.findOne({ userId });
  const line = cart && cart.items.find((l) => String(l.foodId) === req.params.foodId);
  if (!line) throw new AppError('This item is not in your cart', 404);

  line.quantity = quantity;
  await cart.save();

  const view = await buildCartView(userId);
  res.json({ success: true, message: 'Quantity updated', data: view });
});

// DELETE /api/cart/items/:foodId
exports.removeItem = asyncHandler(async (req, res) => {
  const userId = getUserId();
  const cart = await Cart.findOne({ userId });
  const line = cart && cart.items.find((l) => String(l.foodId) === req.params.foodId);
  if (!line) throw new AppError('This item is not in your cart', 404);

  cart.items = cart.items.filter((l) => String(l.foodId) !== req.params.foodId);
  await cart.save();

  const view = await buildCartView(userId);
  res.json({ success: true, message: 'Item removed from cart', data: view });
});
