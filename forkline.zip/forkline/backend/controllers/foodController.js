// controllers/foodController.js
// Handles:  GET /api/foods

const Food = require('../models/Food');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const { asString, escapeRegex, isValidId, parseLimit } = require('../utils/helpers');

// GET /api/foods?search=pizza&category=Burger&restaurantId=<id>&popular=true&limit=8
// All parameters are optional and can be combined.
exports.getFoods = asyncHandler(async (req, res) => {
  const search = asString(req.query.search);
  const category = asString(req.query.category);
  const restaurantId = asString(req.query.restaurantId);
  const filter = {};

  if (search) {
    filter.name = new RegExp(escapeRegex(search), 'i');
  }
  if (category && category.toLowerCase() !== 'all') {
    filter.category = new RegExp(`^${escapeRegex(category)}$`, 'i');
  }
  if (restaurantId) {
    if (!isValidId(restaurantId)) throw new AppError('Invalid restaurant ID', 400);
    filter.restaurantId = restaurantId;
  }
  if (req.query.popular === 'true') {
    filter.isPopular = true;
  }

  const foods = await Food.find(filter)
    .populate('restaurantId', 'name location')
    .sort({ isPopular: -1, name: 1 })
    .limit(parseLimit(req.query.limit));

  res.json({ success: true, count: foods.length, data: foods });
});
