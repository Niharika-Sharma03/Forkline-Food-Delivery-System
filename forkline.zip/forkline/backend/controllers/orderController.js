// controllers/orderController.js
// Handles:  POST /api/orders              (place an order from the demo user's cart)
//           GET  /api/orders/:orderRef    (look up an order, e.g. FLK-261021-A3F9C2)
//
// The frontend only sends the customer's name, phone and address.
// The items and prices ALWAYS come from the cart + foods collections in MongoDB.

const crypto = require('crypto');
const Cart = require('../models/Cart');
const Food = require('../models/Food');
const Order = require('../models/Order');
const asyncHandler = require('../middleware/asyncHandler');
const { AppError } = require('../middleware/errorHandler');
const { asString, roundMoney } = require('../utils/helpers');

const getUserId = () => process.env.DEMO_USER_ID || 'demo-user';

// Creates a readable reference such as FLK-261021-A3F9C2
function makeOrderRef() {
  const yymmdd = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  const random = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `FLK-${yymmdd}-${random}`;
}

// Validates the customer details. Returns { values, errors }.
function validateCustomer(body) {
  const errors = [];

  const customerName = asString(body.customerName);
  if (customerName.length < 2 || customerName.length > 60) {
    errors.push({ field: 'customerName', message: 'Name must be 2 to 60 characters' });
  }

  // Accept "98765 43210", "+91 98765-43210", "09876543210" ... and keep 10 digits
  let phone = String(body.phone === undefined || body.phone === null ? '' : body.phone)
    .replace(/[\s\-()]/g, '')
    .replace(/^(\+91|91|0)(?=\d{10}$)/, '');
  if (!/^[6-9]\d{9}$/.test(phone)) {
    errors.push({ field: 'phone', message: 'Enter a valid 10-digit Indian mobile number' });
  }

  const address = asString(body.address);
  if (address.length < 10 || address.length > 250) {
    errors.push({ field: 'address', message: 'Address must be 10 to 250 characters' });
  }

  return { values: { customerName, phone, address }, errors };
}

// POST /api/orders      body: { customerName, phone, address }
exports.createOrder = asyncHandler(async (req, res) => {
  // 1. Validate the form input
  const { values, errors } = validateCustomer(req.body || {});
  if (errors.length > 0) {
    throw new AppError('Please correct the highlighted fields', 400, errors);
  }

  // 2. Load the cart from MongoDB
  const userId = getUserId();
  const cart = await Cart.findOne({ userId });
  if (!cart || cart.items.length === 0) {
    throw new AppError('Your cart is empty. Add some food before placing an order.', 400);
  }

  // 3. Load the real dishes and prices from MongoDB
  const foods = await Food.find({ _id: { $in: cart.items.map((line) => line.foodId) } });
  const foodById = new Map(foods.map((food) => [String(food._id), food]));

  const orderItems = [];
  const problems = [];
  let totalAmount = 0;

  for (const line of cart.items) {
    const food = foodById.get(String(line.foodId));
    if (!food) {
      problems.push('An item in your cart no longer exists');
    } else if (!food.isAvailable) {
      problems.push(`${food.name} is currently unavailable`);
    } else {
      const subtotal = roundMoney(food.price * line.quantity);
      orderItems.push({
        foodId: food._id,
        name: food.name,
        price: food.price,
        quantity: line.quantity,
        subtotal,
      });
      totalAmount += subtotal;
    }
  }

  if (problems.length > 0) {
    throw new AppError(`${problems.join('. ')}. Please update your cart and try again.`, 409);
  }

  // 4. Save the order (retry with a new reference in the very rare case of a duplicate)
  let order;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      order = await Order.create({
        orderRef: makeOrderRef(),
        userId,
        ...values,
        items: orderItems,
        totalAmount: roundMoney(totalAmount),
      });
      break;
    } catch (err) {
      if (err.code !== 11000 || attempt === 3) throw err;
    }
  }

  // 5. Clear the cart. If this fails we delete the order again, so the database
  //    never ends up with "order saved but cart still full".
  try {
    await Cart.updateOne({ userId }, { $set: { items: [] } });
  } catch (err) {
    await Order.deleteOne({ _id: order._id }).catch(() => {});
    throw new AppError('We could not complete your order. Please try again.', 500);
  }

  res.status(201).json({ success: true, message: 'Order placed successfully', data: order });
});

// GET /api/orders/:orderRef
exports.getOrderByRef = asyncHandler(async (req, res) => {
  const orderRef = asString(req.params.orderRef).toUpperCase();
  const order = await Order.findOne({ orderRef, userId: getUserId() });
  if (!order) throw new AppError('Order not found', 404);

  res.json({ success: true, data: order });
});
