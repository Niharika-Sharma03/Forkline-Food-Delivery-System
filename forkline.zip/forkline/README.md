# 🍴 Forkline — Food Delivery Web Application

A full-stack food delivery app built for an MCA practical:
**HTML / CSS / JavaScript / Bootstrap 5** (frontend) → **Express REST API** (backend) → **MongoDB** (database).

Every major feature talks to the backend: restaurants, menus, search, filters, cart and orders are all stored in or read from MongoDB.

---

## 1. Folder structure

```
forkline/
├── backend/
│   ├── config/db.js              MongoDB connection (retries if MongoDB is down)
│   ├── models/                   Restaurant.js, Food.js, Cart.js, Order.js
│   ├── controllers/              restaurant, food, cart, order logic
│   ├── routes/                   URL -> controller mapping
│   ├── middleware/               error handler, DB check, ID validation
│   ├── utils/helpers.js          small shared functions
│   ├── seed.js                   sample data (6 restaurants, 30 dishes)
│   ├── server.js                 starts the API
│   ├── .env.example              settings template
│   └── package.json
├── frontend/
│   ├── index.html  restaurants.html  menu.html  cart.html  checkout.html
│   ├── css/style.css
│   └── js/  api.js  main.js  restaurants.js  menu.js  cart.js  checkout.js
└── README.md
```

---

## 2. Database setup (MongoDB + Compass)

1. Install **MongoDB Community Server** and **MongoDB Compass** (both free).
2. Make sure MongoDB is running:
   - **Windows:** it normally runs as a service. If not, open *Command Prompt as Administrator* and run `net start MongoDB`.
   - **macOS:** `brew services start mongodb-community`
   - **Linux:** `sudo systemctl start mongod`
3. Create the settings file (inside `backend/`):
   - Windows PowerShell: `copy .env.example .env`
   - macOS / Linux: `cp .env.example .env`
4. The default connection string in `.env` is `mongodb://127.0.0.1:27017/forkline`.
   You do **not** need to create the database by hand: MongoDB creates `forkline` and its four collections automatically when the seed script inserts the first records.

### Verify the data in MongoDB Compass
1. Open Compass → connect to `mongodb://127.0.0.1:27017` → **Connect**.
2. After seeding, click the **forkline** database. You should see:

| Collection | Expected after `npm run seed` |
|---|---|
| `restaurants` | 6 documents |
| `foods` | 30 documents |
| `carts` | appears after the first "Add to cart" (1 document, `userId: "demo-user"`) |
| `orders` | appears after the first order |

3. Open `carts` while using the website: the `items` array changes every time you add, change or remove an item. That proves the cart is stored in MongoDB.
4. **Demo trick:** in `foods`, edit any dish and set `isAvailable` to `false`. It shows as *Unavailable* on the site and can no longer be added or ordered.

---

## 3. Run the project (VS Code terminal)

```bash
# 1. go to the backend folder
cd forkline/backend

# 2. install dependencies (first time only)
npm install

# 3. put sample data into MongoDB (safe to run again and again)
npm run seed

# 4. start the API
npm start
```

You should see:
```
🍴 Forkline API running on http://localhost:5000
✅ MongoDB connected: forkline
```

**Open the website** (choose one):

- **Easiest:** open **http://localhost:5000** in Chrome. The Express server also serves the `frontend` folder.
- **Or with Live Server:** install the *Live Server* VS Code extension, right-click `frontend/index.html` → *Open with Live Server*. The page runs on port 5500 and calls the API on port 5000 (CORS is enabled).

Other commands: `npm run dev` (auto-restart while coding) and `npm run seed:reset` (delete all restaurants, foods and carts, then insert fresh data; orders are kept).

---

## 4. API reference and test requests

Base URL: `http://localhost:5000/api`. Quick checks can be done by pasting GET links in Chrome.
For POST / PATCH / DELETE use the **Thunder Client** VS Code extension, Postman, or `curl` (on Windows PowerShell write `curl.exe`).

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Server and database status |
| GET | `/api/restaurants?search=&cuisine=&featured=&limit=` | List / search / filter restaurants |
| GET | `/api/restaurants/:id` | One restaurant |
| GET | `/api/restaurants/:id/foods?search=&category=` | A restaurant's menu |
| GET | `/api/foods?search=&category=&restaurantId=&popular=&limit=` | Search / filter all dishes |
| GET | `/api/cart` | Demo user's cart with totals |
| POST | `/api/cart/items` | Add item: `{ "foodId": "...", "quantity": 1 }` |
| PATCH | `/api/cart/items/:foodId` | Set quantity: `{ "quantity": 3 }` (1 to 10) |
| DELETE | `/api/cart/items/:foodId` | Remove item |
| POST | `/api/orders` | Place order: `{ "customerName", "phone", "address" }` |
| GET | `/api/orders/:orderRef` | Look up an order |

Success responses look like `{ "success": true, "count": 2, "data": [...] }`.
Errors look like `{ "success": false, "message": "...", "errors": [...] }`.

### Sample requests and expected results (IDs will differ on your machine)

```bash
# Health
curl http://localhost:5000/api/health
# -> 200 {"success":true,"server":"running","database":"connected"}

# Search restaurants (matches name or cuisine)
curl "http://localhost:5000/api/restaurants?search=pizza"
# -> 200 {"success":true,"count":1,"data":[{"_id":"...","name":"Napoli Wood Fire","cuisine":"Pizza, Italian", ...}]}

# Filter dishes by category
curl "http://localhost:5000/api/foods?category=Burger"
# -> 200 count 4 (all with "category":"Burger")

# Invalid restaurant id
curl http://localhost:5000/api/restaurants/abc
# -> 400 {"success":false,"message":"Invalid restaurant ID"}

# Unknown (but well-formed) restaurant id
curl http://localhost:5000/api/restaurants/000000000000000000000000
# -> 404 {"success":false,"message":"Restaurant not found"}

# Add to cart (replace FOOD_ID with an _id from /api/foods)
curl -X POST http://localhost:5000/api/cart/items -H "Content-Type: application/json" -d '{"foodId":"FOOD_ID","quantity":2}'
# -> 201 {"success":true,"message":"... added to cart","data":{"items":[...],"totalItems":2,"totalAmount":598}}

# Bad quantity
curl -X PATCH http://localhost:5000/api/cart/items/FOOD_ID -H "Content-Type: application/json" -d '{"quantity":99}'
# -> 400 {"success":false,"message":"Quantity must be a whole number between 1 and 10"}

# Place order (empty cart first -> 400 "Your cart is empty ...")
curl -X POST http://localhost:5000/api/orders -H "Content-Type: application/json" \
  -d '{"customerName":"Niharika Sharma","phone":"9876543210","address":"House 12, Sector 70, Mohali"}'
# -> 201 {"success":true,"message":"Order placed successfully","data":{"orderRef":"FLK-261021-A3F9C2","totalAmount":598,"orderStatus":"Placed", ...}}

# Invalid phone
# -> 400 {"success":false,"message":"Please correct the highlighted fields","errors":[{"field":"phone","message":"Enter a valid 10-digit Indian mobile number"}]}
```

### Feature test checklist

- [ ] Home page loads restaurants and popular dishes from the API (skeletons show briefly)
- [ ] Clicking a category button on the home page reloads dishes from `/api/foods?category=...`
- [ ] Hero search → opens Restaurants page with results
- [ ] Restaurants page: typing in search waits ~0.4 s, then calls the API (watch Chrome DevTools → Network)
- [ ] Cuisine buttons filter restaurants; "No restaurants found" appears for nonsense text
- [ ] **View Menu** opens `menu.html?id=...` with the restaurant banner and its dishes
- [ ] Menu category buttons and search filter through the API
- [ ] `menu.html?id=abc` shows "Restaurant not found" (invalid ID handling)
- [ ] Add to cart → toast appears, navbar badge bumps, document appears in Compass `carts`
- [ ] Cart page: + / − change quantity, trash removes, totals update, refresh keeps the cart
- [ ] Empty cart shows the empty-state message and "Start shopping"
- [ ] Checkout: empty or invalid fields show red messages; valid form places the order
- [ ] Order confirmation shows order reference, items, total and delivery details; navbar badge goes to 0
- [ ] Compass: new document in `orders`; `carts.items` is empty
- [ ] Refreshing the confirmation page (`checkout.html?order=FLK-...`) loads the order from the API again
- [ ] Stop MongoDB (or the server) and reload: a friendly error with **Try again** appears; start it again and click **Try again**
- [ ] Set a dish's `isAvailable` to `false` in Compass: it shows *Unavailable* and cannot be added
- [ ] Resize the browser / use Chrome DevTools device mode: layout works on mobile, tablet and desktop

---

## 5. Explanation for the practical examination

**Aim.** To integrate a responsive frontend with REST APIs and a MongoDB database into a complete full-stack food delivery application.

**Architecture (3 layers).**
1. **Frontend** – HTML, CSS, Bootstrap and vanilla JavaScript. It shows the pages and never stores data permanently.
2. **Backend** – Node.js + Express. It exposes REST API URLs, validates input and applies the business rules.
3. **Database** – MongoDB, accessed through Mongoose models. It stores restaurants, foods, carts and orders.

**API flow (example: add to cart).**
`Add button click` → `fetch('POST /api/cart/items')` in `api.js` → Express route → `cartController.addItem` → checks the food exists and is available → saves in the `carts` collection → sends back the updated cart → frontend updates the navbar badge and shows a toast.

**Database usage.**
- `restaurants` and `foods` are linked: each food stores its `restaurantId`.
- `carts` stores only `foodId` + `quantity`, one document per (demo) user.
- `orders` stores a snapshot of the items and prices at the time of ordering.

**Important design decisions (good viva points).**
- *Prices are never trusted from the browser.* The cart stores only IDs and quantities; the server reads prices from MongoDB and calculates every total.
- *Search and filters run in the backend* using query parameters and MongoDB queries, not by looping over arrays in JavaScript.
- *Debouncing* (400 ms) stops an API call on every single key press.
- *Validation twice:* the browser checks the form for quick feedback, and the server checks again because browser checks can be bypassed.
- *Consistency:* the order is saved first, then the cart is cleared; if clearing fails, the order is deleted again so the data never ends up half-done. (With a MongoDB replica set, a database *transaction* would be the alternative.)
- *Error handling:* `try/catch` around every `fetch`, HTTP status checking, clear messages for server down, database down, invalid IDs, empty results, failed cart operations and failed orders.
- *No login:* a fixed demo user (`demo-user`) owns the cart, as allowed by the project brief.

**Expected output.** A colourful, responsive food delivery site where a user can browse restaurants, search and filter food, fill a cart that is saved in MongoDB, place an order and see an order reference, and where the same records are visible in MongoDB Compass.

---

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection failed` in the terminal | MongoDB is not running – start it (section 2). The server keeps retrying by itself. |
| Browser shows "Cannot reach the Forkline server" | Run `npm start` in `backend/` and check `http://localhost:5000/api/health`. |
| Pages are empty / "No restaurants yet" | Run `npm run seed`. |
| Port 5000 already in use | Change `PORT` in `.env` and open that port. If you use Live Server, also set `window.FORKLINE_API_BASE` in `api.js`. |
| Some food photos show a plate icon | The image link is unreachable or offline. The fallback picture is shown automatically; replace the URL in `seed.js` and run `npm run seed` again. |
